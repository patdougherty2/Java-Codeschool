//Simple outline of BlackJackGame 

import java.util.Scanner;

public class BlackJackGame {
    
    //Declare variables 
	private Scanner bj = new Scanner(System.in);
	private int users; 
	private Player[] players;
	private Deck deck;
	private Dealer dealer = new Dealer();
    
    // Starts game and displays the rules
    public void initializeGame(){

        System.out.println("Welcome to BlackJackGame!");

        //Print Out BlackJackGame Rules
        System.out.println("BlackJack Rules: ");  
        
       //Record the amount of players 
       System.out.print("How many players? ");  

       players = new Player[users];
       deck = new Deck();
    }

   //Code to shuffle cards 

   //Play the game 
   
   // Include bets, deals, checks, hits, etc. 

   //Print out status/score of the game -- In other words the results
   public void status(){

        //Print out each players scores
        System.out.println("Scores ");  
        System.out.println("Player 1:  "); 
}

   //Print out if want to play again or end game
   public void finishedGame(){

        System.out.print("Play Again or End Game? ");  

   }
  
}