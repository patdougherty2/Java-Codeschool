public class helloWorld {
    public static void main(String[] args) {

        //Print the words "hello world" on the screen
        System.out.println(" Hello World!");
    }
}
