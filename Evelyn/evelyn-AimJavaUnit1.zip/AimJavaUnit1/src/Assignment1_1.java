public class Assignment1_1 {

    public static void main(String[] args) {
        //print out my name
        System.out.println("Evelyn Espinoza-Macias");
        //print out class name
        System.out.println("Java Web");
        //print out home town
        System.out.println("Omaha, NE");
        //print out my favorite dessert
        System.out.println("Chocolate cake");
    }
}