public class Assignment1_2 {
    
    public static void main(String[] args) {
        //print out first line
        System.out.println("     J    A    V    V     A");
        //print out second line
        System.out.println("     J   A A   V    V    A A");
        //print out third line
        System.out.println("J    J  AAAAA   V   V   AAAAA");
        //print out fourth line
        System.out.println("  J J  A     A    V    A     A ");
    }
}
