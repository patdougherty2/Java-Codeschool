public class Assignment {
    public static void main(String[] args)  {
        String firstName = "Evelyn"; 

        String lastName = " Espinoza-Macias"; 

        String city = "Omaha";

        String fourthString = firstName + lastName; 

        System.out.println(fourthString);
        System.out.println(city);
    }
}
