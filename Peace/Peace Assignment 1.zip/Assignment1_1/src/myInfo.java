public class myInfo {
    public static void main(String[] args){
        System.out.println("Peace Kanu-Asiegbu");
        System.out.println("Full Stack Java 2021");
        System.out.println("Omaha, NE");
        System.out.println("Homemade Icecream");
    }

    
}