public class assignment2 {
    public static void main(String[] args){
        System.out.println("     J      A      V       A");
        System.out.println("    JJJ     AAAA    VVVV    AAAAAA");
        System.out.println("   JJJJ    AAAAAAAA   VVV     AAAA");
        System.out.println("  JJJJ   A       V         A    "); 
        System.out.println(" JJJ  AAA      VVVV         A"); 
        int cadence = 0 ;
        System.out.println(cadence); 
        int omaha = 2000;
        System.out.println(omaha); 
        omaha = omaha + 5 ;
        System.out.println(omaha); 
        int speedlimit = 65; 
        float speed, speed3;
        speed = 65;
        speed3 = speed/3; 
        System.out.println(speed3);  
    }
    
}
