public class uml {
    public static void main(String[] args) {

        double width1 = 40;
        double height1 = 4;

        double width2 = 5;
        double height2 = 3.5;

        double area1 = width1 * height1;
        double area2 = width2 * height2;

        double perimeter1 = 2 * width1 * height1;
        double perimeter2 = 2 * width2 * height2;

        System.out.println("Rectangle 1: ");
        System.out.println(width1);
        System.out.println(height1);
        System.out.println(area1);
        System.out.println(perimeter1); 

        System.out.println("Rectangle 2: ");
        System.out.println(width2);
        System.out.println(height2);
        System.out.println(area2);
        System.out.println(perimeter2); 

        System.out.println("Goodbye...");



   

    }
  


    


       
}
