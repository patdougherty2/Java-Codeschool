public class Week3 {
   
    
    public static void main(String[] args) {
       String firstString = "Peace";
       String secondString = " Kanu-Asiegbu";
       String thirdString = " Omaha";
       String fourthString = firstString + secondString;
       System.out.println(fourthString + thirdString); 
    }
}
