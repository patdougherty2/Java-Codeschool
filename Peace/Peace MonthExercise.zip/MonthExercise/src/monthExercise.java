
import java.util.Scanner; 

public class monthExercise {
    public static void main (String[] args) {

        //Tell the user what the program does 
        //Prompts the user to enter the value for the month
        System.out.println("Given a year and a month in that year, this program will tell you");
        System.out.println("the number of days in that month");

        //Prompt the user to enter a year
        System.out.println("Enter a year: ");;

        Scanner input = new Scanner(System.in);
        int year = input.nextInt();

        //Prompt the user to enter a value for the month
        System.out.println("Enter a value for the month (1 = Jan, 2= Feb, etc): ");
        int month = input.nextInt(); 

        //Close our Scanner objectc/Input Stream 
        input.close();

        int days = 0;
        String nameofMonth = null;

        if (month == 1) {
            nameofMonth = "January";
            days = 31;   
        }else if (month == 2) {
            nameofMonth = "February";
            boolean isLeapYear = (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
            if (isLeapYear) {
                days = 29;
            }else {
                days = 28; 
            }  
        }else if (month == 3) {
            nameofMonth = "March";
            days = 31;
        }else if (month == 4) {
            nameofMonth = "April";
            days = 30;
        }else if (month == 5) {
            nameofMonth = "May";
            days = 31;
        }else if (month == 6) {
            nameofMonth = "June";
            days = 30;
        }else if (month == 7) {
            nameofMonth = "July";
            days = 31;
        }else if (month == 8) {
            nameofMonth = "August";
            days = 30;
        }else if (month == 9) {
            nameofMonth = "September";
            days = 30;
        }else if (month == 10) {
            nameofMonth = "October"; 
            days = 31;
        }else if (month == 11) {
            nameofMonth = "November";
            days = 30;
        }else if (month == 12) {
            nameofMonth = "December";
            days = 31;
        }
        System.out.println("nameOfMonth" + " of " + year + " has " + days + " days in it.");
        
    }
    
}

