import java.util.Scanner;

public class wk3Assignment {
    public static void main(String[] args) {

        //Prompt user to input info
        System.out.println("\nEnter your first name.\n");
        Scanner input = new Scanner(System.in);
        String nameFirst = input.nextLine();
        
        System.out.println("\nEnter your last name.\n");
        String nameLast = input.nextLine();

        System.out.println("\nEnter your hometown.\n");
        String nameCity = input.nextLine();
        
        //Close scanner input stream
        input.close();

        //Concatination of name
        String nameTotal = nameFirst + " " + nameLast;

        //Output full string
        System.out.println("\nYou are " + nameTotal + " and you are from " + nameCity + ".\n");
    }
}
