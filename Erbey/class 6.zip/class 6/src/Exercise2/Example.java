package Exercise2;

import java.util.Arrays;
import java.util.Random;

public class Example {
    public static void main(String[] args) {
        
    }
}
