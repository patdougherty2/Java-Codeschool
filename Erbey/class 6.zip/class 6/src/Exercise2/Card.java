package Exercise2;

import java.util.Arrays;
import java.util.Random;

public class Card {
    for (int i = 0; i < 13; i++) {
        
    }
}
