package Exercise1;

public class Example {
    public static void main(String[] args) {
        System.out.println("This program creates two rectangle objects and displays their width, height, area, and perimiter.\n");

        //Prints out rec1
        Rectangle rec1 = new Rectangle(4, 40);
        System.out.format("Rectangle 1: \n");
        System.out.format("height = %4.2f\n", rec1.getHeight());
        System.out.format("width = %4.2f\n", rec1.getWidth());
        System.out.format("area = %4.2f\n", rec1.getArea());
        System.out.format("perimeter = %4.2f\n\n", rec1.getPerimeter());

        //prints out rec2
        Rectangle rec2 = new Rectangle(3.5, 5);
        System.out.format("Rectangle 2: \n");
        System.out.format("height = %4.2f\n", rec2.getHeight());
        System.out.format("width = %4.2f\n", rec2.getWidth());
        System.out.format("area = %4.2f\n", rec2.getArea());
        System.out.format("perimeter = %4.2f\n\n", rec2.getPerimeter());
    
        System.out.println("Goodbye...");
    }
}
