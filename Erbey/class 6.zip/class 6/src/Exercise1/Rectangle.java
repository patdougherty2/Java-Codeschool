package Exercise1;

public class Rectangle {
    double height = 1;
    double width = 1;

    //empty method which defaults all values to 1 if no values passed
    public Rectangle() {
    }

    //creates object given values
    public Rectangle(double height, double width) {
        this.height = height;
        this.width = width;
    }

    //method which returns corresponding values when called
    public double getHeight() {
        return this.height;
    }
    public double getWidth() {
        return this.width;
    }
    public double getArea(){
        return width * height;
    }
    public double getPerimeter() {
        return (2 * width) + (2 * height);
    }
}
