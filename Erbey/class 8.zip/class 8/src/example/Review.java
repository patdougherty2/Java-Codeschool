package example;
import java.io.IOException;
import java.nio.file.*;
import java.util.List;

public class Review {
    public static void main(String[] args){
        try {
            loadFile("files.txt");
        } catch (IOException e) {
            System.out.println(e);
        }
    }

    static void loadFile(String fileName) throws IOException {
        Path file = FileSystem.getDefault().getPath("", fileName);
        List<String> lines = Files.readAllLines(file);
        /*for (int i = 0; i < lines.size(); i++) {
            System.out.println(lines.get(i));
        }*/

        //lines.forEach((str) -> System.out.println(str));
        lines.forEach(System.out::println);
    }
}
