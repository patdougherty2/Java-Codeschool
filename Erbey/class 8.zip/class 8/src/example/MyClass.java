package example;

public class MyClass {
    int myInt = 5;

    MyClass() {
        System.out.println("constructor");
    }

    void myMethod() {
        System.out.println("my method");
    }
}
