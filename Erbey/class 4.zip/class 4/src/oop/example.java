package oop;

public class example {
    public static void main(String[] args) {
        Vehicle vehicle1 = new Vehicle();
        System.out.println(vehicle1.getName());
        vehicle1.setName("city");
        System.out.println(vehicle1.getName());

        Vehicle vehicle2 = new Vehicle("civic", "black", "2012", "honda");
        System.out.println(vehicle2.getColor());
        vehicle2.setColor("green");
        System.out.println(vehicle2.getColor());
    }
}
