public class test {
    public static void main(String[] args) {
        int cadence = 10;
        int omaha = 2000;
        System.out.println(cadence);
        System.out.println(omaha);
        omaha = omaha + 5;
        System.out.println(omaha);
        int speedlimit = 65;
        float speed, speed3;
        speed = 65;
        speed3 = speed / 3;
        System.out.println(speed3);
    }
}
