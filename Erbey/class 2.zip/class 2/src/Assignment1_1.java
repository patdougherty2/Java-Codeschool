public class Assignment1_1 {
    public static void main(String[] args) {
        System.out.println("Erbey Uribe");
        System.out.println("Java Web");
        System.out.println("Omaha, NE");
        System.out.println("Vanilla IceCream");
    }
}